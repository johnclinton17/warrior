<?php
/**
*Template Name: Untamed Page
*/

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<!-- banner -->
<section class="innerbanner about-page untamedpg" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center 0 /cover ;"> 
  <div class="container">
      <div class="row"> 
          <div class="wrap-banner-content">
            <div class="wrap-text">
              <h2><?php the_title();?></h2>
            </div>
          </div>
      </div>
    </div>
</section>      
<!-- banner -->

<!-- about wild warrior -->
<section class="about-page-content">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-centered">
          <div class="page-about-content untamed_introduction">
            <?php the_field('introduction_content');?>
          </div>
      </div>
    </div>
  </div>
</section>
<!-- about wild warrior -->

<section class="yellowband">
  <div class="container"> 
    <div class="row"> 
      <div class="col-sm-12"> <h3> <?php the_field('yellow_band_title');?> </h3> </div>
    </div>
  </div>
</section>

<!-- athletes section -->
 <section class="untamed_athletes">
  <div class="container">
    
    <?php if(have_rows('athlets_row')): while (have_rows('athlets_row')):the_row(); ?>
     <div class="row utrw"> 
      <div class="col-sm-6 col-lg-6 clm1 wow zoomIn"> 
        <div class="hdname"> <h3><span> <?php the_sub_field('athlet_name');?> </span></h3> </div>
        <div class="description"> 
          <?php the_sub_field('athlet_description');?>
          <div class="followtxt"> Follow <?php the_sub_field('athlet_follow');?> here </div>
          <div class="followicon"> <a href="<?php the_sub_field('instagram_link');?>">@<?php the_sub_field('athlet_instagram');?></a> </div>
        </div>
      </div>
      <div class="col-sm-6 col-lg-6 clm2 wow zoomIn"> 
        <div class="imagediv"><img src="<?php the_sub_field('athlet_image'); ?>" alt="<?php the_sub_field('athlet_name');?>"></div>
      </div>
    </div> 
    <?php endwhile; else : endif; ?>   

  </div>
</section>
<!-- athletes section -->

<?php endwhile; // end of the loop. ?>	
<?php
get_footer();
