<?php
/**
*Template Name: About Us
*/

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<!-- banner -->
<section class="innerbanner about-page" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center 0 /cover ;"> 
  <div class="container">
      <div class="row"> 
          <div class="wrap-banner-content">
            <div class="wrap-text">
              <h2><?php the_title();?></h2>
            </div>
          </div>
      </div>
    </div>
</section>      
<!-- banner -->

<!-- about wild warrior -->
<section class="about-page-content">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-centered">
          <div class="page-about-content">
            <?php the_field('about_content');?>
          </div>
      </div>
    </div>
  </div>

  <div class="core-image-section">
      <div class="core-desktop">
        <img class="core-layer-4" src="<?php echo get_template_directory_uri() ?>/images/core-value-layer4.png" alt="core values">
        <img class="core-layer-3" src="<?php echo get_template_directory_uri() ?>/images/core-value-layer3.png" alt="core values">
        <img class="core-layer-2" src="<?php echo get_template_directory_uri() ?>/images/core-value-layer2.png" alt="core values">
        <img class="core-layer-1" src="<?php echo get_template_directory_uri() ?>/images/core-value-layer1.png" alt="core values">
      </div>
      <div class="core-mobile">
        <img src="<?php the_field('mobile_image');?>" alt="core values">
          <ul>
            <li>
              <h5>Consistency</h5>
              <p>Regular commitment to what you choose to pursue</p>
            </li>
            <li>
              <h5>Integrity </h5>
              <p>Respect the rules and make honest efforts</p>
            </li>
            <li>
              <h5>Curiosity</h5>
              <p>Being able to push yourself outside your comfort zone and explore the unknown</p>
            </li>
            <li>
              <h5>Persistence</h5>
              <p>Keep fighting and relentlessly persevere until you reach your ultimate goal. Never giving up!</p>
            </li>
            <li>
              <h5>Passion</h5>
              <p>Enjoy pursuing your dream </p>
            </li>
          </ul>
      </div>
  </div>
</section>
<!-- about wild warrior -->

<!-- adventure section -->
<section class="adventure-para">
  <div class="container">
    <div class="row">
      <div class="col-md-7 col-centered">
        <div class="row">
          <div class="adventure-para">
            <!-- <h1><span class="left-coln">'</span>Everyone</h1><h1>Loves Adventure</h1>
            <h3>Obstacles need to be overcome & Competition is in our DNA <span class="right-coln">'</span></h3> -->
            <img src="<?php echo get_template_directory_uri() ?>/images/adventure-text.png" alt="adventure text" class="img-responsive">
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- adventure section -->

<script type="text/javascript">
  
  // banner Animation
 jQuery(document).ready(function(){
         if (jQuery(window).width() < 767) {

         }
         else if (jQuery(window).width() < 1000) {

         }
        else if (jQuery(window).width() < 1280) {
            
        jQuery(document).ready(function() {
          var movementStrength = 40;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".core-image-section").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 10;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.core-layer-3').css("left", newvalueX+"px");
                    jQuery('.core-layer-3').css("top", newvalueY+"px");
            });
        });

          jQuery(document).ready(function() {
          var movementStrength = 40;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".core-image-section").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 10;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.core-layer-1').css("left", newvalueX+"px");
                    jQuery('.core-layer-1').css("top", newvalueY+"px");
            });
        });


        
          }
         else {
           
          jQuery(document).ready(function() {
          var movementStrength = 40;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".core-image-section").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 10;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.core-layer-3').css("left", newvalueX+"px");
                    jQuery('.core-layer-3').css("top", newvalueY+"px");
            });
        });

          jQuery(document).ready(function() {
          var movementStrength = 40;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".core-image-section").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 10;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.core-layer-1').css("left", newvalueX+"px");
                    jQuery('.core-layer-1').css("top", newvalueY+"px");
            });
        });

      }});

</script>
<?php endwhile; // end of the loop. ?>	
<?php
get_footer();
