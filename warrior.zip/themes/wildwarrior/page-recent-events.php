<?php
/**
*Template Name: Upcoming Events
*Template Post Type: events
*/

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

  <!-- banner -->
<section class="innerbanner-upcoming-events" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center 0 /cover ;"> 
  <div class="container">
      <div class="row">  
          <div class="event-banner-content" data-center="bottom:0px;" data-top-bottom="bottom:300px;" data-anchor-target=".innerbanner-upcoming-events">
            <div class="col-md-10 col-centered">
              <div class="row">
                <div class="flex-row">
                  <div class="event-banner-left wow fadeIn">
                    
                      <h1><?php the_field('title');?></h1>
                      <h5><?php the_field('date');?></h5>
                      <div class="poweredby">
                        <span class="powered-text">Powered by</span>
                        <img src="<?php the_field('powered_by_logo');?>" alt="powered-logo">
                      </div>
                      <a class="orange-button desktop-orange-button" href="<?php the_field('registration_link');?>">Register now</a>
                    
                  </div>
                  <div class="event-banner-right">
                      <div id="event-timer" class="wow fadeIn"></div>
                      <a class="orange-button mobile-orange-button" href="<?php the_field('registration_link');?>">Register now</a>
                      <script>
                        // Set the date we're counting down to
                        var countDownDate = new Date("<?php the_field('timer');?>").getTime();

                        // Update the count down every 1 second
                        var x = setInterval(function() {

                          // Get today's date and time
                          var now = new Date().getTime();
                            
                          // Find the distance between now and the count down date
                          var distance = countDownDate - now;
                            
                          // Time calculations for days, hours, minutes and seconds
                          var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                          var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                          var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                          var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                            
                          // Output the result in an element with id="demo"
                          document.getElementById("event-timer").innerHTML = days + "d  " + hours + "h  " + minutes + "m   " + seconds + "s";
                            
                          // If the count down is over, write some text 
                          if (distance < 0) {
                            clearInterval(x);
                            document.getElementById("event-timer").innerHTML = "EXPIRED";
                          }
                        }, 500);
                      </script>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
</section>      
<!-- banner -->

<!-- about event -->
<section class="about-event">
  <div class="container">
    <div class="row">
      <div class="section-head wow fadeInUp">
          <h1><?php the_field('about_title');?></h1>
      </div>
      <div class="about-event-body wow fadeInUp">
          <?php the_field('about_content');?>
          <a class="orange-button" href="<?php the_field('registration_link');?>">Register now</a>
      </div>
    </div>
  </div>
</section>
<!-- about event -->

<!-- what participant get -->
<?php if(have_rows('icon_row')): ?>
  <section class="participant-section">
     <div class="wrapper">
      <div class="container">
         <div class="section-head wow fadeInUp">
          <h1>What Participant’s Get</h1>
         </div> 
         <div class="icons-row">
          <?php while (have_rows('icon_row')):the_row(); ?>
            <div class="col-lg-2 col-md-4 col-sm-4 col-xs-6 icon-box wow zoomIn">
              <div class="icon"><img src="<?php the_sub_field('icon'); ?>" alt="icons"></div>
              <div class="icon-text"><?php the_sub_field('icon_text'); ?></div>
            </div>
          <?php endwhile; ?> 
         </div>
      </div>
     </div> 
  </section>
<?php endif; ?>  
<!-- what participant get -->

<!-- notice section -->
<section class="notice-section">
  <div class="important-notice">
    <div class="container">
      <div class="row">
        <div class="col-md-10 col-centered">
          <div class="row">
              <div class="flex-row">
                  <div class="points-list wow fadeInUp">
                    <?php the_field('important_notice'); ?>
                  </div>
                  <div class="sponsor-list wow fadeInUp">
                    <h4>OUR Sponsors</h4>
                    <?php if(have_rows('sponsor_images')): ?>
                      <ul>
                        <?php while (have_rows('sponsor_images')):the_row(); ?>
                        <li><img src="<?php the_sub_field('images');?>" alt="powered-logo"></li>
                        <?php endwhile; ?>
                      </ul>
                    <?php endif; ?> 
                  </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="upcoming-post">
      <!-- upcoming events -->
        <div class="container">
          <div class="row">
            <div class="title-head"><h1>Upcoming Events</h1></div>
            <div class="box-events-row">
              <?php $options = array('post_type' => 'events','posts_per_page' => 6,'orderby' => 'date','order' => 'ASC','paged' => $paged,'tax_query' => array(array('taxonomy' => 'events_category','field' => 'slug','terms' => 'upcoming-events')));
                $query = new WP_Query( $options ); if ( $query->have_posts() ) : while($query->have_posts()) : $query->the_post(); $event_thumbnail1 = get_field('event_thumbnail', $options->ID);?>
                <div class="box-events wow fadeIn">
                  <a href="<?php echo get_permalink($options->ID) ?>">
                  <div class="box-image" style="background:url('<?php echo $event_thumbnail1 ?>') no-repeat scroll center center / cover ;"></div>
                  <div class="box-content">
                    <div class="text-left">
                      <h2><?php the_title();?></h2>
                      <h4><?php echo $location = get_field('location', $options->ID); ?></h4>
                      <h4><?php echo $date = get_field('date', $options->ID); ?></h4>
                    </div>
                    <div class="button-right"><a class="orange-button" href="<?php echo get_permalink($options->ID) ?>">Register now</a></div>
                  </div>
                  </a>
                </div>
              <?php endwhile; wp_reset_query();endif; ?>
            </div>
          </div>
        </div>
      <!-- upcoming events -->
  </div>
</section>
<!-- notice section -->











<script type="text/javascript">
  // skrllr
 jQuery(function () {
  
  // Init function
  function skrollrInit() {

    skrollr.init({
    smoothScrolling: false,
    mobileDeceleration: 0.004,
    forceHeight: false,
    });

    }
    // If window width is large enough, initialize skrollr
    if (jQuery(window).width() > 1024) {
      skrollrInit();
    }

    jQuery(window).on('resize', function () {
      var _skrollr = skrollr.get(); // get() returns the skrollr instance or undefined
      var windowWidth = jQuery(window).width();

      if ( windowWidth <= 1024 && _skrollr !== undefined ) {
        _skrollr.destroy();
      } else if ( windowWidth > 1024 && _skrollr === undefined ) {
        skrollrInit();
      }
    });
  });
</script>


<?php endwhile; // end of the loop. ?>	
<?php
get_footer();
