<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WP_Bootstrap_Starter
 */

get_header(); ?>



		<div class="singlewrapper">
			<?php 
	if ( have_posts() ) :
	while ( have_posts() ) : the_post(); 
		$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );?>
			<!-- <div class="back-float"><a href="<?php echo home_url('/') ?>blog">Back to blog</a></div> -->

				<div class="content-area">
					<section class="s-content s-content--top-padding s-content--narrow">
						<article class="row entry format-standard">
						<div class="entry__media col-full">
							<div class="entry__post-thumb" style="background:url(<?php echo $featureimg ?>)no-repeat center /cover"></div>
						</div>
						<div class="entry__header col-full">
							<h1 class="entry__header-title display-1"><?php the_title(); ?></h1>
							<ul class="entry__header-meta">
								<li class="date"><?php echo get_the_date('F j, Y'); ?></li>
								<li class="byline">By <?php echo get_the_author(); ?></li>
							</ul>
						</div>
						<div class="col-full entry__main">
							<?php the_content(); ?>
						</div>
						</article>
					</section>
						<?php
							// If comments are open or we have at least one comment, load up the comment template
							//if ( comments_open() || '0' != get_comments_number() ) :
							//	comments_template();
							//endif;
						?>
					</div>				
			<?php endwhile;endif;?>

			</div> <!-- content area -->
			<section class="s-content blog-related-post">
				  <div class="container">
				    <div class="row">
				  			<h2 class="related-title">Related Posts</h2>
							        <div class="newsrow">
							          <?php
										$custom_query_args = array( 
											'category__in' => wp_get_post_categories($post->ID),
											'posts_per_page' => 3, 
											'post__not_in' => array($post->ID), 
											);
										$custom_query = new WP_Query( $custom_query_args );
										if ( $custom_query->have_posts() ) : ?>
											<?php while ( $custom_query->have_posts() ) : $custom_query->the_post(); $featureimg1= wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>
							          <div class="col-md-4 col-sm-4 col-xs-12 related-post wow fadeIn">
							            <div class="blog-wrapper">
							              <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
							                <div class="blog-image" style="background:url('<?php echo $featureimg1 ?>') no-repeat center / cover;"></div>
							                <div class="blog-content">
							                  
							                  <p><?php echo get_the_date('F j, Y'); ?></p>
							                  <h2><?php the_title(); ?></h2>
							                </div>
							              </a>
							            </div>
							          </div>
							       
							          <?php endwhile; ?>
											<?php else : ?>
												<p>Sorry, no related articles to display.</p>
										<?php endif;
										wp_reset_postdata();
										?>
							        </div> <!-- news room -->
				
							    
						 

				    </div>
				  </div>
			</section>
			


<?php
get_footer(); ?>

