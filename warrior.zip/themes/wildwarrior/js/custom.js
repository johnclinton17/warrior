jQuery(window).scroll(function(){if(jQuery(window).scrollTop() >= 100) {jQuery('.navbar-static-top').addClass('fixed');} else {jQuery('.navbar-static-top').removeClass('fixed');}});
jQuery(window).load(function(){jQuery(".flexslider").length&&jQuery(".flexslider").flexslider({animation:"slide",controlNav:!0,prevText:"",nextText:"",smoothHeight:!0,slideshowSpeed:10000,directionNav: false,controlNav:true})});
jQuery(document).ready(function(){jQuery(".name input,.city input").keypress(function(event){ var inputValue = event.charCode;if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){event.preventDefault(); }});});
jQuery(".wpcf7-tel").keypress(function(event) {return /\d/.test(String.fromCharCode(event.keyCode));});

