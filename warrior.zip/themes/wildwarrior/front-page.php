<?php
/**
* Template Name: front-page
 */

get_header(); ?>

<!--page contentrs starts here-->
  <main class="page_template">
    <!-- banner section -->
    <section class="banner_section">
      <div class="flexslider">
            <ul class="slides">
                <?php
                $args = array( 'posts_per_page' => 5,'post_type' =>'home_banner','post_status'=> 'publish','orderby' => 'date','order' => 'ASC');
                $bannerposts = get_posts( $args );
                foreach ( $bannerposts as $bpost ) : setup_postdata( $bpost );
                $bannerimg = wp_get_attachment_url( get_post_thumbnail_id($bpost->ID) );
                $custom=get_post_custom($bpost->ID);?>
                    <li>
                      <div class="bannerfill" style="background:url('<?php echo $bannerimg;?>') no-repeat scroll center center / cover ;">
                        <div class="container parent">
                          <div class="row">
                              <div class="content" data-center="bottom:0px;" data-top-bottom="bottom:250px;" data-anchor-target=".bannerfill">
                                <?php the_content();?>
                              </div>
                            </div>
                        </div>
                      </div>
                    </li>     
                <?php endforeach; wp_reset_postdata();?>
            </ul>
        </div>
      </section>
      <!-- banner section -->

      <!-- upcoming events -->
      <section class="upcoming-events">
        <div class="container">
          <div class="row">
            <div class="title-head"><h1>Upcoming Events</h1></div>
            <div class="box-events-row">
              <?php $options = array('post_type' => 'events','posts_per_page' => 6,'orderby' => 'date','order' => 'ASC','paged' => $paged,'tax_query' => array(array('taxonomy' => 'events_category','field' => 'slug','terms' => 'upcoming-events')));
                $query = new WP_Query( $options ); if ( $query->have_posts() ) : while($query->have_posts()) : $query->the_post(); $event_thumbnail1 = get_field('event_thumbnail', $options->ID);?>
                <div class="box-events wow fadeIn">
                  <a href="<?php echo get_permalink($options->ID) ?>">
                  <div class="box-image" style="background:url('<?php echo $event_thumbnail1 ?>') no-repeat scroll center center / cover ;">
                  </div>
                  <div class="box-content">
                    <div class="text-left">
                      <h2><?php the_title();?></h2>
                      <h4><?php echo $location = get_field('location', $options->ID); ?></h4>
                      <h4><?php echo $date = get_field('date', $options->ID); ?></h4>
                    </div>
                    <div class="button-right"><a class="orange-button" href="<?php echo get_permalink($options->ID) ?>">Register now</a></div>
                  </div>
                </a>
                </div>
              <?php endwhile; wp_reset_query();endif; ?>
            </div>
          </div>
        </div>
      </section>
      <!-- upcoming events -->

      <!-- about wild warrior -->
      <section class="about-wildwarrior">
        <div class="container">
          <div class="row">
            <div class="col-md-8 col-centered">
              <div class="content-about">
                <h1><?php the_field('about_title');?></h1>
                <?php the_field('about_content');?>
              </div>
            </div>
          </div>
        </div>  
      </section>
      <!-- about wild warrior -->

      <!-- recent events -->
      <section class="recent-events">
        <div class="container">
          <div class="row">
              <div class="title-head"><h1>Recent Events</h1></div>
          </div>
        </div> 
        <div class="recent-slider">
          <?php $options = array('post_type' => 'events','posts_per_page' => 6,'orderby' => 'date','order' => 'ASC','paged' => $paged,'tax_query' => array(array('taxonomy' => 'events_category','field' => 'slug','terms' => 'recent-events')));
          $query = new WP_Query( $options ); if ( $query->have_posts() ) : while($query->have_posts()) : $query->the_post(); $event_thumbnail = get_field('event_thumbnail', $options->ID);?>
                <div class="slide-wrapper" style="background:url('<?php echo $event_thumbnail ?>') no-repeat scroll center center / cover ;">
                  <div class="slider-box-content">
                    <div class="orange-masked">
                      <div class="text-left">
                        <h2><?php the_title();?></h2>
                        <h4><?php echo $location = get_field('location', $options->ID); ?></h4>
                      </div>
                      <div class="button-right"><a href="<?php echo get_permalink($options->ID) ?>">View  details</a></div>
                    </div>
                  </div>
                </div>
             <?php endwhile; wp_reset_query();endif;?>
        </div>
      </section>
      <!-- recent events -->

      <!-- featured athlete -->
      <section class="featured-athele">
        <div class="container">
          <div class="row">
            <div class="col-md-10 col-centered">
            <div class="slide-wrapper" >
              <div class="left-image-div wow fadeInUp" style="background: url('<?php the_field('athlete_image');?>') no-repeat 0 0 / cover;"></div>
              <div class="right-content-div wow slideInLeft">
                <h3><span>Featured Athlete</span></h3>
                <div class="left-image-div mobile-athlete" style="background: url('<?php the_field('athlete_image');?>') no-repeat 0 0 / cover;"></div>
                <h1><?php the_field('athlete_name');?></h1>
                <p><?php the_field('athlete_bio');?></p>  
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- featured athlete -->

      <!-- from blog -->
      <section class="blog-post-row">
        <div class="container">
          <div class="row">
              <div class="title-head"><h1>From Our Blog</h1></div>
              <div class="post-row">
                <?php  $the_query = new WP_Query( array('posts_per_page' => 3 ,'orderby' => 'date','order' => 'DSC')); ?>
                  <?php if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post() ;
                    $featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );  ?>
                      <div class="col-md-4 col-sm-4 col-xs-12 blog-post wow fadeInUp">
                        <div class="entry">
                          <div class="entry__image" >
                            <img src="<?php echo $featureimg ?>">
                          </div>
                          <div class="entry__content">
                            <h1><a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a></h1>
                            <div class="date-blog"><?php echo get_the_date('F j, Y'); ?></div>
                            <p><?php echo wp_trim_words( get_the_content(), 25 ,'...' ); ?></p>
                            <a href="<?php the_permalink(); ?>" class="readmore"> read more</a>
                          </div>
                        </div>
                      </div>
                <?php endwhile; endif; ?>
              </div>
          </div>
        </div>
      </section>
      <!-- from blog -->
      
      <!-- instagram feeds -->
      <section class="instagram-row">
        <div class="container">
          <div class="row">
               <div class="title-head"><h1>Shots from our Instagram</h1><p>Join the tribe on Instagram by tagging @wildwarriorrace</p></div>
               <div class="insta-row wow fadeIn">
                  <?php echo do_shortcode('[wdi_feed id="1"]'); ?>
               </div>
          </div>
        </div>
      </section>
      <!-- instagram feeds -->
  </main>

<?php
get_footer();?>
