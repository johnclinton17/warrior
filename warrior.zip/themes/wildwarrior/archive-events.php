<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WP_Bootstrap_Starter
 */

get_header(); ?>

  <div id="primary" class="content-area col-sm-12 col-md-12">
    <main id="main" class="site-main" role="main">
      <?php if ( have_posts() ) : ?>
        <div class="title-head">
          <?php the_archive_title( '<h1 class="page-title">', '</h1>' );?>
        </div>
        <!-- upcoming events -->
            <section class="upcoming-events">
              <div class="container">
                <div class="row">
                
                  <div class="box-events-wrapper">
                    <?php while ( have_posts() ) : the_post(); ?>
                  <?php 
                        $box_value = get_sub_field('events'); 
                        $location = get_field('location', $box_value);
                        $date = get_field('date', $box_value);
                        $event_thumbnail = get_field('event_thumbnail', $box_value);
                      ?>
                    <div class="box-events wow fadeIn">
                      <div class="box-image" style="background:url('<?php echo $event_thumbnail ?>') no-repeat scroll center center / cover ;">
                        <?php the_post_thumbnail(); ?>
                      </div>
                      <div class="box-content">
                        <div class="text-left">
                          <h2><?php the_title(); ?></h2>
                          <h4><?php echo $location ?></h4>
                          <h4><?php echo $date ?></h4>
                        </div>
                        <div class="button-right"><a href="<?php the_permalink(); ?>">Register now</a></div>
                      </div>
                    </div>
                    <?php endwhile;?>
                  </div>
                </div>
              </div>
            </section>

          
      <?php endif; ?>

    </main><!-- #main -->
  </div><!-- #primary -->

<?php get_footer();
