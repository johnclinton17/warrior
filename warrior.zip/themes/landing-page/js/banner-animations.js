 // header fixed
 $(window).scroll(function(){
      if ($(window).scrollTop() >= 100) {
        $('.header-toolbar').addClass('fixed');
       }
       else {
        $('.header-toolbar').removeClass('fixed');
       }
    });
 // banner Animation
 jQuery(document).ready(function(){
         if (jQuery(window).width() < 767) {

         }
         else if (jQuery(window).width() < 800) {

         }
        else if (jQuery(window).width() < 1367) {
            
        jQuery(document).ready(function() {
          var movementStrength = 50;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 0;
                    var newvalueY = height * pageY * -1 + 100;
                    jQuery('.white-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 50;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 200;
                    var newvalueY = height * pageY * -1 + 200;
                    jQuery('.green-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 20;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 0;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.blue-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });

        jQuery(document).ready(function() {
          var movementStrength = 10;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 100;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.circle-info').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 40;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".squadrun-section").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 10;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.warrior-logo').css("left", newvalueX+"px");
                    jQuery('.warrior-logo').css("top", newvalueY+"px");
            });
        });

        
          }
         else {
           
        jQuery(document).ready(function() {
          var movementStrength = 50;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 0;
                    var newvalueY = height * pageY * -1 + 100;
                    jQuery('.white-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 50;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 200;
                    var newvalueY = height * pageY * -1 + 200;
                    jQuery('.green-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 100;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 50;
                    var newvalueY = height * pageY * -1 + 0;
                    jQuery('.blue-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 10;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 100;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.circle-info').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 40;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".squadrun-section").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 10;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.warrior-logo').css("left", newvalueX+"px");
                    jQuery('.warrior-logo').css("top", newvalueY+"px");
            });
        });
         }

        }); 

 // scroll detector
  window.addEventListener('scroll', function() {
    var element = document.querySelector('.who-we-are');
    var position = element.getBoundingClientRect();
    // checking for partial visibility
    if(position.top < window.innerHeight && position.bottom >= 0) {
      var a = 0;
    if (a == 0 ) {
      jQuery('.count').each(function() {
        var $this = jQuery(this),
          countTo = $this.attr('data-count');
        jQuery({
          countNum: $this.text()
        }).animate({
            countNum: countTo
          },

          {

            duration: 1000,
            easing: 'linear',
            step: function() {
              $this.text(Math.floor(this.countNum));
            },
            complete: function() {
              $this.text(this.countNum);
              //alert('finished');
            }

          });
      });
      a = 1;
    }
    }
  });


// slick slider
 var slickPrimarySecondary = {
       slidesToShow: 1,
       slidesToScroll: 1,
       arrows: false,
       fade: false,
       infinite: true,
       draggable:false
    };
    var slickNavigator = {
       slidesToShow: 1,
       autoplay: true,
       slidesToScroll: 1,
       arrows: false,
       asNavFor: '.text-bg',
       speed: 500,
       dots: true,
       focusOnSelect:true,
       centerMode: false,
       infinite: true,
       draggable:false
    };


 $('.text-bg').slick(slickPrimarySecondary);
 $('.main-bg').slick(slickNavigator);

   $('.participants-slider').slick({
    dots: true,
    infinite: true,
    arrows: false,
    speed: 1000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
  });

  // form validation number and text
  jQuery(document).ready(function(){
    jQuery("#name,#designation").keypress(function(event){
        var inputValue = event.charCode;
        if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){
            event.preventDefault();
        }
    });


    //allow only numbers
      jQuery(document).ready (function () {
          jQuery("#phone").keypress (function (event) {
              if ((event.which < 32) || (event.which > 126)) return true; 
              return jQuery.isNumeric (jQuery(this).val () + String.fromCharCode (event.which));
          });// numeric.keypress;
          
      });// document.ready;
});

// back to top
      jQuery(document).ready(function() {
        var offset = 220;
        var duration = 500;
      jQuery(window).scroll(function() {
        if (jQuery(this).scrollTop() > offset) {
            jQuery('.back-to-top').fadeIn(duration);
        } else {
            jQuery('.back-to-top').fadeOut(duration);
        }
      });
    
      jQuery('.back-to-top').click(function(event) {
        event.preventDefault();
        jQuery('html, body').animate({scrollTop: 0}, duration);
        return false;
      })
    });

// skrllr
 jQuery(function () {
  
  // Init function
  function skrollrInit() {

    skrollr.init({
    smoothScrolling: false,
    mobileDeceleration: 0.004,
    forceHeight: false,
    });

    }
    // If window width is large enough, initialize skrollr
    if (jQuery(window).width() > 801) {
      skrollrInit();
    }

    jQuery(window).on('resize', function () {
      var _skrollr = skrollr.get(); // get() returns the skrollr instance or undefined
      var windowWidth = jQuery(window).width();

      if ( windowWidth <= 800 && _skrollr !== undefined ) {
        _skrollr.destroy();
      } else if ( windowWidth > 801 && _skrollr === undefined ) {
        skrollrInit();
      }
    });
  });

  jQuery(document).ready(function(){
      if (jQuery(window).width() < 800) {
           
        }
       else {
           // jQuery('.parallax').css('height', jQuery(window).height());
      jQuery('.main-content-wrapper').stickyStack();

      }
      });