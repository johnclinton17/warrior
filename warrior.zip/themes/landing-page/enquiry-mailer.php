
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Name</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $name; ?></td>
     </tr>
       <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Designation</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $designation; ?></td>
     </tr>
       <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Phone</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $phone; ?></td>
     </tr>
     <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Email</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $email; ?></td>
     </tr>
       <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Message</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $message; ?></td>
     </tr>
   </table>
