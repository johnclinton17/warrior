<?php	
    if(isset($_POST['txt_st']) && $_POST['txt_st'] == "")
	{
		$name = trim($_POST["name"]);
		$designation = trim($_POST["designation"]);
		$phone = trim($_POST["phone"]);
		$email = trim($_POST["email"]);
		$message = trim($_POST["message"]);

		?>		
		<?PHP
		//die();

		
		$to = "varun@wildwarriorrace.com;info@wildwarriorrace.com";
		$from= "info@wildwarriorrace.com";
		$cc= "varun.gunaseelan@gmail.com;";
		$sub = "Wild Warrior Squadrun Enquiry Form.";
		$headers ="From:".$from."\r\n";
		$headers .= "cc: ".$cc." \r\n";
		$headers .= "MIME-Version: 1.0\n"; //#-- Mime version
		$headers .= "Content-Type: text/HTML; charset=ISO-8859-1\n";
		$headers .= "Content-Transfer-Encoding: 8bit\n\n"; 
		
		?>			
				<?PHP 	
						ob_start();
						require_once("enquiry-mailer.php");
						$message_email = ob_get_contents();
						ob_end_flush();
				?>	
		 <?PHP
				mail($to,$sub,$cc,$message_email,$headers);
		        ob_flush();
				echo "success";
				die();
					?>
		<?
		     }//fake
			  else
			 {//fake
			echo "error";
		?>	 
		<?PHP
			}	//fake
		?>