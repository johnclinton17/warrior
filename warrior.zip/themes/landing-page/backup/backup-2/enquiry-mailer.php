<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<style>
body,table,tr,td{font-family:Arial;}
</style>
</head>

<body>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Name</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $name; ?></td>
     </tr>
       <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Designation</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $designation; ?></td>
     </tr>
       <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Phone</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $phone; ?></td>
     </tr>
     <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Email</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $email; ?></td>
     </tr>
       <tr>
        <td width="150" height="35" align="left" valign="middle"><strong>Message</strong></td>
        <td align="left" valign="middle">:</td>
        <td align="left" valign="middle"><?PHP echo $message; ?></td>
     </tr>
   </table>
    
<span style="color:#ddd"><?php
$ip = getenv("REMOTE_ADDR") ; 
echo "IP " . $ip;
?>
   </span> 
   
    
</body>
</html>