<?PHP 
if(isset($_POST['txt_st']) && $_POST['txt_st'] == "")
{
 ?>

			<?PHP 
			
	
		$name = trim($_POST["name"]);
		$designation = trim($_POST["designation"]);
		$phone = trim($_POST["phone"]);
		$email = trim($_POST["email"]);
		$message = trim($_POST["message"]);
		?>
		    <span style="display:none ;">
			<?PHP
            ob_start();
            include("enquiry-mailer.php");
            $message = ob_get_contents();
            ob_end_flush();
            ?>
            </span>		
            <?PHP
		
		$to = "john@niyati.com";
		$cc = "john@trackehs.com";
			$frm = $email;
			//$frm = 'info@trackehs.com';
			$subject = "Enquiry Form.";
			$headers = "MIME-Version: 1.0\n"; //#-- Mime version
			$headers .= "Content-Type: text/HTML; charset=ISO-8859-1\n";
			$headers .= "Cc: $cc \n";
			$headers .= "From: $frm \r\n";
			//$headers .= "Content-Transfer-Encoding: 8bit\n\n";
			$ok = mail($to,$subject,$message,$headers);
		
		// 			?>
		
		 <?PHP			 	
}

?>