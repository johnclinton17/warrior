$.validator.addMethod("validate_email", function(value, element) {

    if (/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value)) {
        return true;
    } else {
        return false;
    }
}, "Please enter a valid Email.");
  $('#sign_up').validate({
        // initialize the plugin
        rules: {
            name:"required",
            designation:"required",
            phone:"required",
            email: {
                required: true,
                email: true,
                validate_email: true
            },
            message:"required"
        },
        messages: {
                name: "Please provide your name",
                designation: "Please enter your designation",
                phone: "Please provide your phone number",
                email: "Please provide us your work email",
                message:"Please enter your comments",
            },

        submitHandler: function (form,event) { 
		event.preventDefault();
		if($('#g-recaptcha-response').val()=='')
		{
		alert('Please Validate Your Captcha');
		return false;
		}
 
         $('#submit').attr('disabled','disabled');
         $.ajax({
            url: 'enquiry.php',
            type: 'post',
            data:{'txt_st':'','name':$('#name').val(),'designation':$('#designation').val(),'phone':$('#phone').val(),'email':$('#email').val(),'message':$('#message').val()},
            beforeSend: function()
            {
            $('#submit').val('sending...');
            },
            success: function(response){
            if(response)
            { 
             $('#sucess').show();
             $('#submit').val('Submit');  
             $('#submit').removeAttr('disabled','disabled');
             $('#name,#designation,#phone,#email,#message').val('')    
            }
            else
            {
            $('#error').show(); 
            $('#submit').val('Submit');  
            $('#submit').removeAttr('disabled','disabled');
            $('#name,#designation,#phone,#email,#message').val('')      
            }
            },
        });

         return false;
        }
       
    });