 jQuery(document).ready(function(){
         if (jQuery(window).width() < 1025) {

         }
        else if (jQuery(window).width() < 1367) {
            
        jQuery(document).ready(function() {
          var movementStrength = 50;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 0;
                    var newvalueY = height * pageY * -1 + 100;
                    jQuery('.white-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 50;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 200;
                    var newvalueY = height * pageY * -1 + 200;
                    jQuery('.green-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 20;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 0;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.blue-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });

        jQuery(document).ready(function() {
          var movementStrength = 10;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 100;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.circle-info').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 40;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".squadrun-section").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 10;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.warrior-logo').css("left", newvalueX+"px");
                    jQuery('.warrior-logo').css("top", newvalueY+"px");
            });
        });
        // jQuery(document).ready(function() {
        //   var movementStrength = 10;
        //   var height = movementStrength / jQuery(window).height();
        //   var width = movementStrength / jQuery(window).width();
        //   jQuery(".squadrun-section").mousemove(function(e){
        //             var pageX = e.pageX - (jQuery(window).width() / 1);
        //             var pageY = e.pageY - (jQuery(window).height() / 1);
        //             var newvalueX = width * pageX * -1 + 10;
        //             var newvalueY = height * pageY * -1 + 50;
        //             jQuery('.image-back').css("left", newvalueX+"px");
        //             jQuery('.image-back').css("bottom", newvalueY+"px");
        //     });
        // });
        
          }
         else {
           
        jQuery(document).ready(function() {
          var movementStrength = 50;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 0;
                    var newvalueY = height * pageY * -1 + 100;
                    jQuery('.white-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 50;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 200;
                    var newvalueY = height * pageY * -1 + 200;
                    jQuery('.green-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 100;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 50;
                    var newvalueY = height * pageY * -1 + 0;
                    jQuery('.blue-star').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 10;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".banner-animation").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 100;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.circle-info').css("background-position", newvalueX+"px     "+newvalueY+"px");
            });
        });
        jQuery(document).ready(function() {
          var movementStrength = 40;
          var height = movementStrength / jQuery(window).height();
          var width = movementStrength / jQuery(window).width();
          jQuery(".squadrun-section").mousemove(function(e){
                    var pageX = e.pageX - (jQuery(window).width() / 1);
                    var pageY = e.pageY - (jQuery(window).height() / 1);
                    var newvalueX = width * pageX * -1 + 10;
                    var newvalueY = height * pageY * -1 + 50;
                    jQuery('.warrior-logo').css("left", newvalueX+"px");
                    jQuery('.warrior-logo').css("top", newvalueY+"px");
            });
        });
        // jQuery(document).ready(function() {
        //   var movementStrength = 10;
        //   var height = movementStrength / jQuery(window).height();
        //   var width = movementStrength / jQuery(window).width();
        //   jQuery(".squadrun-section").mousemove(function(e){
        //             var pageX = e.pageX - (jQuery(window).width() / 1);
        //             var pageY = e.pageY - (jQuery(window).height() / 1);
        //             var newvalueX = width * pageX * -1 + 10;
        //             var newvalueY = height * pageY * -1 + 50;
        //             jQuery('.image-back').css("left", newvalueX+"px");
        //             jQuery('.image-back').css("bottom", newvalueY+"px");
        //     });
        // });




         }

        }); 

 // scroll detector
  window.addEventListener('scroll', function() {
    var element = document.querySelector('.who-we-are');
    var position = element.getBoundingClientRect();
    // checking for partial visibility
    if(position.top < window.innerHeight && position.bottom >= 0) {
      var a = 0;
    if (a == 0 ) {
      jQuery('.count').each(function() {
        var $this = jQuery(this),
          countTo = $this.attr('data-count');
        jQuery({
          countNum: $this.text()
        }).animate({
            countNum: countTo
          },

          {

            duration: 1000,
            easing: 'linear',
            step: function() {
              $this.text(Math.floor(this.countNum));
            },
            complete: function() {
              $this.text(this.countNum);
              //alert('finished');
            }

          });
      });
      a = 1;
    }
    }
  });

